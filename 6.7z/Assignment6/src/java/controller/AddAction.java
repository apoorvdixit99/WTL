/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import com.opensymphony.xwork2.ActionSupport;

import model.AdditionModel;

/**
 *
 * @author DELL
 */
public class AddAction extends ActionSupport{
    private AdditionModel additionModel;
    
    String name;
    int num1;
    int num2;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNum1() {
        return num1;
    }

    public void setNum1(int num1) {
        this.num1 = num1;
    }

    public int getNum2() {
        return num2;
    }

    public void setNum2(int num2) {
        this.num2 = num2;
    }

    public AdditionModel getAdditionModel() {
        return additionModel;
    }

    public void setAdditionModel(AdditionModel additionModel) {
        this.additionModel = additionModel;
    }
    
    @Override
    public String execute(){
        setAdditionModel(new AdditionModel(name, num1, num2));
        return "SUCCESS";
    }
    
    
}
